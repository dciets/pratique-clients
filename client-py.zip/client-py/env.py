PORT: int = 10000
# HOST: str = '172.16.10.1'
HOST: str = '127.0.0.1'
ID: str = '349e9ccf-c52d-4121-8dae-82d5262e9cca'

MAGIC: int = 0x11223344
SUPER_ADMIN_PORT: int = 10002
